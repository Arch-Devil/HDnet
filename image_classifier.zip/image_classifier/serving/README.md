
Pytorch Serving (待debug)

```
docker-compose up -d
```


可参考：https://github.com/MachineLP/QDServing
